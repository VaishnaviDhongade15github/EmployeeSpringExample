package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeService { //I_EmployeeService

	//Design the method which take Employee as argument
	//and return Employee object
	
	public Employee saveEmployee(Employee employee);
	
	//Design the method which return employee object by fetching it DB from ID
	
	public Employee getEmployeeById(Integer id);
	
	//Design the method which return list of employee
	public List<Employee>getAllEmployee();
	
	//Design the method to delete the record based  on id
	public void deleteEmployeeById(Integer id);
	
	
		
	
	
	
	
}

package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeRepository;
import com.example.demo.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Employee saveEmployee(Employee employee) {

		return employeeRepository.save(employee);
	}

	@Override
	public Employee getEmployeeById(Integer id) {
		// Optional<Employee> employee =employeeRepository.findById(id);
	   Employee	emp= employeeRepository.getById(id);
		 System.out.println("Employee Record:" +emp);
		return emp;
	}

	@Override
	public List<Employee> getAllEmployee() {
	  List <Employee>listEmployee=employeeRepository.findAll();
		return listEmployee;
	}

	@Override
	public void deleteEmployeeById(Integer id) {
		employeeRepository.deleteById(id);
		
	}


	
}
